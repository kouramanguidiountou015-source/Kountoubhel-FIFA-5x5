KOUNTOUBHEL FIFA 5x5 — version de démarrage
- Ouvre static/index.html dans un navigateur pour tester la page.
- Pour publier le site, crée un dépôt GitHub et ajoute le dossier.
- Cette version organise les championnats et calcule des estimations à partir des cotes saisies.
- Elle ne récupère PAS automatiquement les données de 1xBet. Il faut une API/un flux dont l'accès est autorisé par le fournisseur.
- Ne donne jamais ton mot de passe 1xBet à ce robot. Il ne place aucun pari.
- Les scores sont indicatifs et le modèle n'est pas validé sur un historique complet.
